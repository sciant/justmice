$(document).ready(function() {
	$.getScript("assets/plugins/wow/dist/wow.min.js", function(){
		new WOW().init();
	});
});